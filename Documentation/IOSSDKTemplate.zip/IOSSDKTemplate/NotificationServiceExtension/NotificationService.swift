//
//  NotificationService.swift
//  NotificationServiceExtension
//
//  Created by Selligent Marketing Cloud on 27/07/2018.
//  Copyright © 2018 Selligent Marketing Cloud. All rights reserved.
//

import UserNotifications
import SelligentMobileSDK

class NotificationService: UNNotificationServiceExtension {
    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {
        // Init and start the SDK
        let url = "YourProvidedURL"
        let clientID = "YourClientID"
        let privateKey = "YourPrivateKey"

        // Create the SMManagerSetting instance
        let settings: SMManagerSetting = SMManagerSetting(url: url, clientID: clientID, privateKey: privateKey)

        // Provide the App Group Id to the SDK
        settings.appGroupId = "group.selligent.push"

        // Start the SDK
        SMManager.sharedInstance().startExtension(with: settings)

        // Provide the request with the original Notification content to the SDK and the contentHandler
        SMManager.sharedInstance().didReceive(request, withContentHandler: contentHandler)
    }
}
