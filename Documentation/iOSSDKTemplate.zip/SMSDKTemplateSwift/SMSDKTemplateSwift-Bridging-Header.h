//
//  SMSDKTemplateSwift-Bridging-Header.h
//  SMSDKTemplate
//
//  Created by Gilbert Schakal on 03/06/16.
//  Copyright © 2016 Samy Ziat. All rights reserved.
//

#import "SMHelper.h"
