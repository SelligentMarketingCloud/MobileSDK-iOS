//
//  AppDelegate.swift
//  SMSDKTemplateSwift
//
//  Created by Samy Ziat on 21/10/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

import Foundation
import UIKit
import UserNotifications


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let url = "URL"
        let clientID = "ClientID"
        let privateKey = "privateKey"
        
    //  Create the SMManagerSetting instance
        let setting: SMManagerSetting = SMManagerSetting(url: url, clientID: clientID, privateKey: privateKey)
        
        
    //Optional - Default value is true
        setting.shouldClearBadge = true;
        setting.shouldDisplayRemoteNotification = true;
        
    //Optional - Default value is kSMClearCache_Auto
        setting.clearCacheIntervalValue = .auto;
        
    // Optional - Initialise InApp Message settings
        let settingIAM = SMManagerSettingIAM.setting(with: .smia_RefreshType_Daily)
        setting.configureInAppMessageService(withSetting: settingIAM)
        
    // Optional - Initialise InApp Content settings
        let settingIAC = SMManagerSettingIAC.setting(with: .smia_RefreshType_Daily)
        setting.configureInAppContentService(withSetting: settingIAC)
        
    //Optional - Initialise location services - You need plot projects framework (not available in this template project)  and plotconfig.json file in your app to be able to use this - cf. documentation for more information on all available features
        setting.configureLocationService()
        
        let logLevel: SMLogLevel =  .all ;
        
        SMManager.sharedInstance().apply(logLevel);
    // Start the SDK
        SMManager.sharedInstance().start(launchOptions: launchOptions, setting: setting )
        
    // the following commands can be done later depending the needs of your app
        SMManager.sharedInstance().enable(inAppMessage: true)
        SMManager.sharedInstance().registerForRemoteNotification()
        
    //conform to the UNUserNotificationCenterDelegate protocol
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
        } else {
            // Fallback on earlier versions
        }

        //listen to In App message broadcasting
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveInAppMessage(_:)), name: NSNotification.Name(rawValue: kSMNotification_Event_DidReceiveInAppMessage), object: nil)
        
        //listen to In App content messages
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveInAppContent(_:)), name: NSNotification.Name(rawValue: kSMNotification_Event_DidReceiveInAppContent), object: nil)
        
    //Other available braodcastings - check documentation for more informations
        
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameButtonClicked(_:)), name: NSNotification.Name(rawValue: kSMNotification_Event_ButtonClicked), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameWillDisplayNotification(_:)), name: NSNotification.Name.smNotification_Event_WillDisplay, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameWillDismissNotification(_:)), name: NSNotification.Name.smNotification_Event_WillDismiss, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveRemoteNotification(_:)), name: NSNotification.Name.smNotification_Event_DidReceiveRemote, object: nil)
        
        
        //When using a selligent push notification button with a button open method in app (this can be listened anywhere in your app)
        //"CustomActionBroadcastEvent" is an example it can be any string but it must match exactly the value you will set for the button in the push
        NotificationCenter.default.addObserver(self, selector: #selector(customAction(_:)), name: NSNotification.Name(rawValue:"CustomActionBroadcastEvent"), object: nil)
        
        return true
    }
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        SMManager.sharedInstance().didRegisterForRemoteNotifications(withDeviceToken: deviceToken)
    }
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        SMManager.sharedInstance().didRegisterUserNotificationSettings()
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        SMManager.sharedInstance().didFailToRegisterForRemoteNotificationsWithError(error)
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        SMManager.sharedInstance().didReceiveRemoteNotification(userInfo)
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        SMManager.sharedInstance().willPresent(notification)
        completionHandler(.alert) // or any UNNotificationPresentationOptions
        
        //OR alternatively you can call
            // SMManager.sharedInstance().willPresent(notification, withCompletionHandler: completionHandler)
        //In this case the SDK will be in charge to call teh completionhandler for you with .alert as UNNotificationPresentationOptions
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        SMManager.sharedInstance().didReceive(response)
        completionHandler()
        
        //OR alternatively you can call
        // SMManager.sharedInstance().didReceive(response, withCompletionHandler: completionHandler)
        //In this case the SDK will be in charge to call the completionhandler for you
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
        let deviceInfos:SMDeviceInfos = SMDeviceInfos(externalId: "12345")
        SMManager.sharedInstance().sendDeviceInfo(deviceInfos)
        
        //example of display of an image IAC in fullscreen as soon as the application become active
        let iacVC = SMInAppContentImageViewController(forCategory:"yourcategory")
        if(!(iacVC?.isEmpty)!)
        {
            self.window?.rootViewController?.present(iacVC!, animated: true, completion: nil)
        }

    }

    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        //here you will be able to parse your url in case you would like to use deeplinking
        print(url.absoluteString)
        return true
    }
    
    //Notifications selectors
    
    @objc func anyMethodNameDidReceiveInAppMessage(_ notif : Notification){
        let dict = notif.userInfo
        let inAppData = dict![kSMNotification_Data_InAppMessage]
    }
    
    @objc func anyMethodNameDidReceiveInAppContent(_ notif : Notification){
        let dict = notif.userInfo
        let inAppData : NSArray = dict![kSMNotification_Data_InAppContent] as! NSArray
        
        //This is an example to show how to use in app content data by your own
        //This don't have to be done absolutely here
        
        //Retrieve first category returned
        let firstcategory = (inAppData[0] as AnyObject).allKeys[0]
        
        //Get all the in app contents for this category
        let messages = SMManager.sharedInstance().getInAppContents(forCategory: firstcategory as? String, type: .image)
        //Get first message
        let message = messages?[0] as! SMInAppContentMessage
        
        //then you  can process the in app content message like you want using the SMInAppContentMessage properties
        //let messageTitle = (message as! SMInAppContentMessage).title
        //let messageBody = message.body
        
        //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
        SMManager.sharedInstance().setInAppContentAsSeen(message)
        
        //Assuming that the user has triggered a link inside you will have to (and this MANDATORY to inform the services)
        //get the triggered link (in this case the first one)
        let links  = message.arrayIACLinks as Array
        SMManager.sharedInstance().executeLinkAction(links[0] as? SMLink, inAppContent:message );

    }
    
    @objc func anyMethodNameButtonClicked(_ notif : Notification){
        let dict = notif.userInfo
        //let btnData : SMNotificationButtonData = dict![kSMNotification_Data_ButtonData] as! SMNotificationButtonData
    }
    
    @objc func anyMethodNameDidReceiveRemoteNotification(_ notif : Notification){
        let dict = notif.userInfo
        //let notifData = dict![kSMNotification_Data_RemoteNotification];
    }
    
    @objc func anyMethodNameWillDisplayNotification(_ notif : Notification){
    }
    
    @objc func anyMethodNameWillDismissNotification(_ notif : Notification){
    }

    @objc func customAction(_ notif : Notification){
        print("customAction")
    }
}

