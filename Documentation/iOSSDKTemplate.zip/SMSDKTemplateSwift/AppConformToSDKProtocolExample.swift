//
//  File.swift
//  SMSDKTemplateSwift
//
//  Created by Gilbert Schakal on 05/5/2021.
//  Copyright © 2021 Samy Ziat. All rights reserved.
//

import Foundation

class AppConformToSDKProtocolExample: NSObject, WKNavigationDelegate, SMManagerInAppMessageDelegate{
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == .linkActivated  {
            if let url = navigationAction.request.url,
                let host = url.host, !host.hasPrefix("www.google.com"),
                UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                print(url)
                print("Redirected to browser. No need to open it locally")
                SMManager.sharedInstance().removeViewController()
                decisionHandler(.cancel)
            } else {
                print("Open it locally")
                decisionHandler(.allow)
            }
        } else {
            print("not a user click")
            decisionHandler(.allow)
        }
    }
    
    func display(_ inAppMessage: SMInAppMessage) {
        print(inAppMessage.title!)
        print(inAppMessage.body!)
        print(inAppMessage.arrayIAMLinks!)

    }
}
