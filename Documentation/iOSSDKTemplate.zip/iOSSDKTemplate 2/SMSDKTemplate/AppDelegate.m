//
//  AppDelegate.m
//  SMSDKTemplate
//
//  Created by Samy Ziat on 16/10/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

#import "AppDelegate.h"

#import "SMHelper.h"




@implementation AppDelegate




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
        
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
    
//  Don't forget to put -ObjC in Project > Build Settings > Other Linker Flags
    
    NSString *url       = @"YourProvidedURL";
    NSString *clientID  = @"YourClientID";
    NSString *privatKey = @"YourPrivateKey";

// Then:
//  Create the SMManagerSetting instance
    SMManagerSetting *setting = [SMManagerSetting settingWithUrl:url ClientID:clientID PrivateKey:privatKey];

//Optional - Default value is true
    setting.shouldClearBadge = TRUE;
    setting.shouldDisplayRemoteNotification = TRUE;
    
//Optional - Default value is kSMClearCache_Auto
    setting.clearCacheIntervalValue = kSMClearCache_Auto;
//Only mandatory when you want to use a Notification extensions (Service or/and Content)
    setting.appGroupId = @"group.<your group name>";
    
// Initialise InApp Message settings - other constructors exist (cf. documentation)
    SMManagerSettingIAM *iamSetting = [SMManagerSettingIAM settingWithRefreshType:kSMIA_RefreshType_Daily];
    
    [setting configureInAppMessageServiceWithSetting:iamSetting];

// Initialise InApp Content settings - other constructors exist (cf. documentation)
    SMManagerSettingIAC *iacSetting = [SMManagerSettingIAC settingWithRefreshType:kSMIA_RefreshType_Daily];
    
    [setting configureInAppContentServiceWithSetting:iacSetting];

//Initialise location services - You need plot projects framework (not available in this template project)  and plotconfig.json file in your app to be able to use this - cf. documentation for more information on all available features
    [setting configureLocationService];

    
//  Starting the library
    [[SMManager sharedInstance] startWithLaunchOptions:launchOptions Setting:setting];
    
// The following commands can be done later depending the needs of your app
    [[SMManager  sharedInstance] enableInAppMessage:TRUE];
    [[SMManager sharedInstance] registerForRemoteNotification]; // this displays the dialog box for user to let him allow the reception of push notifications
    
    //Listen to differents broadcasting
    //InAppMessage broadcasting
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveInAppMessage:) name:kSMNotification_Event_DidReceiveInAppMessage object:nil];
    
    //InAppContent broadcasting
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveInAppContent:) name:kSMNotification_Event_DidReceiveInAppContent object:nil];
    
    //Other available braodcastings - check documentation for more informations
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameButtonClicked:) name:kSMNotification_Event_ButtonClicked object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameWillDisplayNotification:) name:kSMNotification_Event_WillDisplayNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameWillDismissNotification :) name:kSMNotification_Event_WillDismissNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveRemoteNotification:) name:kSMNotification_Event_DidReceiveRemoteNotification object:nil];
    
    //When using a selligent push notification button with a button open method in app (this can be listened anywhere in your app)
    //"CustomActionBroadcastEvent" is an example it can be any string but it must match exactly the value you will set for the button in the push
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(customAction:) name:@"CustomActionBroadcastEvent" object:nil];
    
    return YES;
}


#pragma mark -
#pragma mark delegate methods


- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken {
    [[SMManager sharedInstance] didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [[SMManager sharedInstance] didRegisterUserNotificationSettings];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    [[SMManager sharedInstance] didFailToRegisterForRemoteNotificationsWithError:error];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    [[SMManager sharedInstance] didReceiveRemoteNotification:userInfo];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    
    SMDeviceInfos *deviceInfos = [SMDeviceInfos deviceInfosWithExternalId:@"123"];
    [[SMManager sharedInstance] sendDeviceInfo:deviceInfos];

    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    //example of display of an image IAC in fullscreen as soon as the application become active
    SMInAppContentImageViewController* iacVC = [SMInAppContentImageViewController viewControllerForCategory:@"yourcategory"];
    if(!iacVC.isEmpty)
        [self.window.rootViewController presentViewController:iacVC animated:YES completion:nil];
}

-(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    //here you will be able to parse your url in case you would like to use deeplinking
    return YES;
}

#pragma mark -
#pragma mark iOS 10 UserNotification delegate methods

-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
    [[SMManager sharedInstance] willPresentNotification:notification withCompletionHandler:completionHandler];
    
    //or:
    
    //[[SMManager sharedInstance] willPresentNotification:notification];
    //completionHandler(UNNotificationPresentationOptionAlert);
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler
{
    [[SMManager sharedInstance] didReceiveNotificationResponse:response withCompletionHandler:completionHandler];
    
    //or:
    
    //[[SMManager sharedInstance] didReceiveNotificationResponse:response];
    //completionHandler();
}


//Notifications selectors

#pragma mark -
#pragma mark Notifications selectors

-(void)anyMethodNameDidReceiveInAppMessage:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    NSDictionary *inAppData = dict[kSMNotification_Data_InAppMessage];
}


-(void)anyMethodNameDidReceiveInAppContent:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    
    //This provide an array with the number of IAC available for a category
    NSArray *inAppData = dict[kSMNotification_Data_InAppContent];
    
    
    //This is an example to show how to use in app content data by your own
    //This don't have to be done absolutely here
    
    //Retrieve first category returned
    NSString *firstcategory = [[inAppData[0] allKeys] firstObject];
    
    //Get all the in app contents for this category
    NSArray * messages =[[SMManager sharedInstance] getInAppContentsForCategory:firstcategory Type:kSMInAppContentType_Image];
    //Get first message
    SMInAppContentMessage * message = [messages firstObject];
    
    //then you  can process the in app content message like you want using the SMInAppContentMessage properties
    NSString *messageTitle = message.title;
    NSString *messageBody = message.body;
    
    //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
    [[SMManager sharedInstance] setInAppContentAsSeen:message];
    
    //Assuming that the user has triggered a link inside you will have to (and this MANDATORY to inform the services)
    //get the triggered link (in this case the first one)
    SMLink *link = message.arrayIACLinks[0];
    [[SMManager sharedInstance] executeLinkAction:link InAppContent:message];
}


-(void)anyMethodNameButtonClicked:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    SMNotificationButtonData *btnData = dict[kSMNotification_Data_ButtonData];
}

-(void)anyMethodNameDidReceiveRemoteNotification:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    NSDictionary *notifData = dict[kSMNotification_Data_RemoteNotification];
}

-(void)anyMethodNameWillDisplayNotification:(NSNotification*)notif{
}

-(void)anyMethodNameWillDismissNotification:(NSNotification*)notif{
}

- (void)customAction:(NSNotification*)notif {
    NSLog(@"customAction");
}

@end
