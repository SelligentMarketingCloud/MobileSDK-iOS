//
//  AppDelegate.m
//  SMSDKTemplate
//
//  Created by Selligent Marketing Cloud on 16/10/15.
//  Copyright (c) 2015 Selligent Marketing Cloud. All rights reserved.
//

#import "AppDelegate.h"
#import "AppConformToSDKProtocolExample.h"

@import SelligentMobileSDK;

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
        
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
    
//  Don't forget to put -ObjC in Project > Build Settings > Other Linker Flags
    
    NSString *url       = @"YourProvidedURL";
    NSString *clientID  = @"YourClientID";
    NSString *privatKey = @"YourPrivateKey";

// Then:
//  Create the SMManagerSetting instance
    SMManagerSetting *setting = [[SMManagerSetting alloc] initWithUrl:url clientId:clientID privateKey:privatKey error:nil];
    
//Optional - Default value is true
    setting.shouldClearBadge = TRUE;
    setting.shouldDisplayRemoteNotification = TRUE;

//Optional - In App messages from push settings
    setting.shouldAddInAppMessageFromPushToInAppMessageList = FALSE;
    
//Optional - Default value is kSMClearCache_Auto
    setting.clearCacheIntervalValue = kSMClearCache_Auto;
//Only mandatory when you want to use a Notification extensions (Service or/and Content)
    setting.appGroupId = @"group.<your group name>";
    
// Initialise InApp Message settings - other constructors exist (cf. documentation)
    SMManagerSettingIAM *iamSetting = [[SMManagerSettingIAM alloc] initWithRefreshType:kSMIA_RefreshType_Daily backgroundFetch:false];
    
    [setting configureInAppMessageServiceWith:iamSetting];

// Initialise InApp Content settings - other constructors exist (cf. documentation)
    SMManagerSettingIAC *iacSetting = [[SMManagerSettingIAC alloc] initWithRefreshType:kSMIA_RefreshType_Daily backgroundFetch:false];
    
    [setting configureInAppContentServiceWith:iacSetting];

//If you use the plot project version of the sdk with geolocation features you can call - otherwise this call is available but has no effect at all
    //[setting configureLocationService];
    
    
//  Starting the library
    [[SMManager shared] startWith:setting];
    
// The following commands can be done later depending the needs of your app
    [[SMManager shared] enableInAppMessage:TRUE];
    [[SMManager shared] registerForRemoteNotification]; // this displays the dialog box for user to let him allow the reception of push notifications

//If you use the plot project version of the sdk you can call - otherwise this method is not available with the standard version of the sdk
    //[[SMManager sharedInstance] enableGeolocation];
    
    //provide an instance of a class to sdk that implements WKNavigationDelegate methods
    [[SMManager shared] inAppMessageWKNavigationDelegate:[AppConformToSDKProtocolExample new]];
    //provide an instance of a class to sdk that implements SMManagerInAppMessageDelegate methods
    [[SMManager shared] inAppMessageDelegate:[AppConformToSDKProtocolExample new]];
    //provide an instance of a class to sdk that implements SMManagerUniversalLinksDelegate methods
    [[SMManager shared] universalLinksDelegate:[AppConformToSDKProtocolExample new]];

    
    //Listen to differents broadcasting
    //InAppMessage broadcasting
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveInAppMessage:) name:SMConstants.kSMNotification_Event_DidReceiveInAppMessage object:nil];
    
    //InAppContent broadcasting
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveInAppContent:) name:SMConstants.kSMNotification_Event_DidReceiveInAppContent object:nil];
    
    //Other available braodcastings - check documentation for more informations
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameButtonClicked:) name:SMConstants.kSMNotification_Event_ButtonClicked object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameWillDisplayNotification:) name:SMConstants.kSMNotification_Event_WillDisplayNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameWillDismissNotification :) name:SMConstants.kSMNotification_Event_WillDismissNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveRemoteNotification:) name:SMConstants.kSMNotification_Event_DidReceiveRemoteNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(anyMethodNameDidReceiveDeviceId:) name:SMConstants.kSMNotification_Event_DidReceiveDeviceId object:nil];
    
    //When using a selligent push notification button with a button open method in app (this can be listened anywhere in your app)
    //"CustomActionBroadcastEvent" is an example it can be any string but it must match exactly the value you will set for the button in the push
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(customAction:) name:@"CustomActionBroadcastEvent" object:nil];
    
    //retrieve device id
    [[SMManager shared] deviceId];
    
    return YES;
}


#pragma mark -
#pragma mark delegate methods

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken {
    [[SMManager shared] didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void) application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    [[SMManager shared] didFailToRegisterForRemoteNotificationsWith:error];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // example of display of an image IAC in fullscreen as soon as the application become active
    SMInAppContentImageViewController* iacVC = [[SMInAppContentImageViewController alloc] initWithCategory:@"yourcategory" options:nil];
    
    if(!iacVC.isEmpty)
        [self.window.rootViewController presentViewController:iacVC animated:YES completion:nil];
}

-(BOOL) application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    //here you will be able to parse your url in case you would like to use deeplinking
    return YES;
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
    [[SMManager shared] willPresent:notification options:nil completionHandler:completionHandler];
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler
{
    [[SMManager shared] didReceive:response options:nil];
    completionHandler();
}


//Notifications selectors

#pragma mark -
#pragma mark Notifications selectors

-(void)anyMethodNameDidReceiveInAppMessage:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    NSDictionary *inAppData = dict[SMConstants.kSMNotification_Data_InAppMessage];
    
    //retrieve inapp messages and display them or store them for future usage and custom display
    NSArray *inAppMessages = [[SMManager shared] getInAppMessages];
    for (SMInAppMessage *message in inAppMessages) {
        NSString * title = message.title;
        //refer to sdk reference document for more available properties (SMBaseMessage and SMInAppMessage class)
        
        //... here for example we will suppose that the message has been displayed  to the user
        //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
        [[SMManager shared] setInAppMessageAsSeen:message];
        
        //flag an In App message as unseen
        [[SMManager shared] setInAppMessageAsUnseen:message];
        
        //flag an In App message as deleted
        [[SMManager shared] setInAppMessageAsDeleted:message];
        
        //Assuming that the user has triggered a link you will have to (and this MANDATORY to inform the services)
        //get the triggered link (in this case the first one)
        if ([message.arrayIAMLinks count] > 0) {
            SMLink *link = message.arrayIAMLinks.firstObject;
            [[SMManager shared] executeLinkAction:link inAppMessage:message];
        }
    }
}


-(void)anyMethodNameDidReceiveInAppContent:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    
    //This provide an array with the number of IAC available for a category
    NSArray *inAppData = dict[SMConstants.kSMNotification_Data_InAppContent];
    
    
    //This is an example to show how to use in app content data by your own
    //This don't have to be done absolutely here
    
    //Retrieve first category returned
    NSString *firstcategory = [[inAppData.firstObject allKeys] firstObject];
    
    //Get all the in app contents for this category
    NSArray * messages = [[SMManager shared] getInAppContentsFor:firstcategory type:kSMInAppContentType_Image];
    //Get first message
    SMInAppContentMessage * message = [messages firstObject];
    
    //then you  can process the in app content message like you want using the SMInAppContentMessage properties
    NSString *messageTitle = message.title;
    NSString *messageBody = message.body;
    
    //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
    [[SMManager shared] setInAppContentAsSeen:message];
    
    //Assuming that the user has triggered a link inside you will have to (and this MANDATORY to inform the services)
    //get the triggered link (in this case the first one)
    if ([message.arrayIACLinks count] > 0) {
        SMLink *link = message.arrayIACLinks.firstObject;
        [[SMManager shared] executeLinkAction:link inAppContent:message];
    }
}


-(void)anyMethodNameButtonClicked:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    SMLink *btnData = dict[SMConstants.kSMNotification_Data_ButtonData];
}

-(void)anyMethodNameDidReceiveRemoteNotification:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    NSDictionary *notifData = dict[SMConstants.kSMNotification_Data_RemoteNotification];
}

-(void)anyMethodNameDidReceiveDeviceId:(NSNotification*)notif{
    NSDictionary *dict = [notif userInfo];
    NSString *deviceId = dict[SMConstants.kSMNotification_Data_DeviceId];
}


-(void)anyMethodNameWillDisplayNotification:(NSNotification*)notif{
}

-(void)anyMethodNameWillDismissNotification:(NSNotification*)notif{
}

- (void)customAction:(NSNotification*)notif {
    NSLog(@"customAction");
}

@end
