//
//  AppConformToSDKProtocolExample.m
//  SMSDKTemplate
//
//  Created by Selligent Marketing Cloud on 12/5/2021.
//  Copyright © Selligent Marketing Cloud. All rights reserved.
//

#import "AppConformToSDKProtocolExample.h"

@import SelligentMobileSDK;

@implementation AppConformToSDKProtocolExample
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(nonnull WKNavigationAction *)navigationAction decisionHandler:(nonnull void (^)(WKNavigationActionPolicy))decisionHandler
{
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated) {
        if (navigationAction.request.URL) {
            NSLog(@"%@", navigationAction.request.URL.host);
            if (![navigationAction.request.URL.resourceSpecifier containsString:@"ex path"]) {
                if ([[UIApplication sharedApplication] canOpenURL:navigationAction.request.URL]) {
                    [[UIApplication sharedApplication] openURL:navigationAction.request.URL options:@{} completionHandler:nil];
                    [[SMManager shared] removeViewController];
                    decisionHandler(WKNavigationActionPolicyCancel);
                }
            } else {
                decisionHandler(WKNavigationActionPolicyAllow);
            }
        }
    } else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

- (void)display:(SMInAppMessage*)inAppMessage
{
    NSLog(@"title : %@", inAppMessage.title);
    NSLog(@"content : %@", inAppMessage.body);
    NSLog(@"links : %@", inAppMessage.arrayIAMLinks);
}

// The below functions are necessary to keep the SDK webview's navigation arrows working
-(void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    [[SMManager shared] webView:webView didFail:navigation withError:error];
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [[SMManager shared] webView:webView didFinish:navigation];
}

-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    [[SMManager shared] webView:webView didCommit:navigation];
}

// Universal link catching
-(void) executeLinkAction:(NSURL *)url {
    NSLog(@"Executing custom universal link action");
}


@end
