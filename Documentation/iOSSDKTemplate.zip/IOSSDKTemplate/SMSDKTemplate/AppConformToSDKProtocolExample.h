//
//  AppConformToSDKProtocolExample.h
//  SMSDKTemplate
//
//  Created by Selligent Marketing Cloud on 12/5/2021.
//  Copyright © 2021 Selligent Marketing Cloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@import SelligentMobileSDK;

NS_ASSUME_NONNULL_BEGIN

@interface AppConformToSDKProtocolExample : NSObject <WKNavigationDelegate, SMManagerInAppMessageDelegate, SMManagerUniversalLinksDelegate>

@end

NS_ASSUME_NONNULL_END
