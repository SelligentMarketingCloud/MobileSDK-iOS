//
//  AppConformToSDKProtocolExample.h
//  SMSDKTemplate
//
//  Created by Gilbert Schakal on 12/5/2021.
//  Copyright © 2021 Samy Ziat. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "SMHelper.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppConformToSDKProtocolExample : NSObject <WKNavigationDelegate, SMManagerInAppMessageDelegate>

@end

NS_ASSUME_NONNULL_END
