//
//  AppDelegate.h
//  SMSDKTemplate
//
//  Created by Selligent Marketing Cloud on 16/10/15.
//  Copyright (c) 2015 Selligent Marketing Cloud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UserNotifications/UserNotifications.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, UNUserNotificationCenterDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

