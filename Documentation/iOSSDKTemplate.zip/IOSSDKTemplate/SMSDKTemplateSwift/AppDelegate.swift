//
//  AppDelegate.swift
//  SMSDKTemplateSwift
//
//  Created by Selligent Marketing Cloud on 21/10/15.
//  Copyright (c) 2015 Selligent Marketing Cloud. All rights reserved.
//

import Foundation
import UIKit
import SelligentMobileSDK

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        let url = "URL"
        let clientID = "ClientID"
        let privateKey = "privateKey"
        
        //  Create the SMManagerSetting instance
        let setting: SMManagerSetting = try! SMManagerSetting(url: url, clientId: clientID, privateKey: privateKey)
        
        //Optional - Default value is true
        setting.shouldClearBadge = true
        setting.shouldDisplayRemoteNotification = true
        
        //Optional - In App messages from push settings
        setting.shouldAddInAppMessageFromPushToInAppMessageList = false
        
        //Optional - Default value is kSMClearCache_Auto
        setting.clearCacheIntervalValue = .auto;
        //Only mandatory when you want to use a Notification extensions (Service or/and Content)
        setting.appGroupId = "group.<your group name>"

        // Optional - Initialise InApp Message settings
        let settingIAM = SMManagerSettingIAM(refreshType: .daily)
        setting.configureInAppMessageService(with: settingIAM)
        
        // Optional - Initialise InApp Content settings
        let settingIAC = SMManagerSettingIAC(refreshType: .daily)
        setting.configureInAppContentService(with: settingIAC)

        let logLevel: SMLogLevel =  .all
        
        SMManager.shared.apply(logLevel);
        // Start the SDK
        SMManager.shared.start(with: setting)
        
        // the following commands can be done later depending the needs of your app
        SMManager.shared.enable(inAppMessage: true)
        SMManager.shared.registerForRemoteNotification()
    
        //provide an instance of a class to sdk that implements WKNavigationDelegate methods
        SMManager.shared.inAppMessageWKNavigationDelegate(AppConformToSDKProtocolExample())
        //provide an instance of a class to sdk that implements SMInAppMessageDelegate methods
        SMManager.shared.inAppMessageDelegate(AppConformToSDKProtocolExample())
        //provide an instance of a class to sdk that implements SMManagerUniversalLinksDelegate methods
        SMManager.shared.universalLinksDelegate(AppConformToSDKProtocolExample())
        
        //conform to the UNUserNotificationCenterDelegate protocol
        if #available(iOS 10.0, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
        } else {
            // Fallback on earlier versions
        }

        //listen to In App message broadcasting
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveInAppMessage(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_DidReceiveInAppMessage), object: nil)
        
        //listen to In App content messages
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveInAppContent(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_DidReceiveInAppContent), object: nil)
        
        //Other available braodcastings - check documentation for more informations
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameButtonClicked(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_ButtonClicked), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameWillDisplayNotification(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_WillDisplayNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameWillDismissNotification(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_WillDismissNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveRemoteNotification(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_DidReceiveRemoteNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.anyMethodNameDidReceiveDeviceId(_:)), name: NSNotification.Name(rawValue: SMConstants.kSMNotification_Event_DidReceiveDeviceId), object: nil)
        
        //When using a selligent push notification button with a button open method in app (this can be listened anywhere in your app)
        //"CustomActionBroadcastEvent" is an example it can be any string but it must match exactly the value you will set for the button in the push
        NotificationCenter.default.addObserver(self, selector: #selector(customAction(_:)), name: NSNotification.Name(rawValue:"CustomActionBroadcastEvent"), object: nil)
        
        //retrieve device id
        print(SMManager.shared.deviceId)
        
        return true
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        SMManager.shared.didRegisterForRemoteNotifications(deviceToken: deviceToken)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        SMManager.shared.willPresent(notification, completionHandler: completionHandler)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        SMManager.shared.didReceive(response)
        completionHandler()
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        //example of display of an image IAC in fullscreen as soon as the application become active
        let iacVC = SMInAppContentImageViewController(category: "yourcategory")
        if(!iacVC.isEmpty)
        {
            self.window?.rootViewController?.present(iacVC, animated: true, completion: nil)
        }

    }

    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        //here you will be able to parse your url in case you would like to use deeplinking
        print(url.absoluteString)
        return true
    }
    
    @objc func anyMethodNameDidReceiveInAppMessage(_ notif : Notification){
        let dict = notif.userInfo
        let inAppData = dict![SMConstants.kSMNotification_Data_InAppMessage]
        
        //retrieve inapp messages and display them or store them for future usage and custom display
        let inAppMessages = SMManager.shared.getInAppMessages()

        for message in inAppMessages {
            let title = message.title
            //refer to sdk reference document for more available properties (SMBaseMessage and SMInAppMessage class)
            
            //... here for example we will suppose that the message has been displayed  to the user
            //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
            SMManager.shared.setInAppMessageAsSeen(message)
            
            //flag an In App message as unseen
            SMManager.shared.setInAppMessageAsUnseen(message)

            //flag an In App message as deleted
            SMManager.shared.setInAppMessageAsDeleted(message)
            
            //Assuming that the user has triggered a link you will have to (and this MANDATORY to inform the services)
            //get the triggered link (in this case the first one)
            SMManager.shared.executeLinkAction(message.arrayIAMLinks.first!, inAppMessage: message)
        }
    }
    
    @objc func anyMethodNameDidReceiveInAppContent(_ notif : Notification){
        let dict = notif.userInfo
        let inAppData : NSArray = dict![SMConstants.kSMNotification_Data_InAppContent] as! NSArray
        
        //This is an example to show how to use in app content data by your own
        //This don't have to be done absolutely here
        
        //Retrieve first category returned
        let firstcategory = (inAppData[0] as! SMInAppContentMessage).category
        
        //Get all the in app contents for this category
        let messages = SMManager.shared.getInAppContents(for: firstcategory, type: .image)
        //Get first message
        let message = messages.first!
        
        //then you  can process the in app content message like you want using the SMInAppContentMessage properties
        //let messageTitle = (message as! SMInAppContentMessage).title
        //let messageBody = message.body
        
        //Assuming that the user has seen the message you will have to (and this MANDATORY to inform the services)
        SMManager.shared.setInAppContentAsSeen(message)
        
        //Assuming that the user has triggered a link inside you will have to (and this MANDATORY to inform the services)
        //get the triggered link (in this case the first one)
        SMManager.shared.executeLinkAction(message.arrayIACLinks.first!, inAppContent:message)
    }
    
    @objc func anyMethodNameButtonClicked(_ notif : Notification){
        let dict = notif.userInfo
        //let btnData : SMLink = dict![kSMNotification_Data_ButtonData] as! SMLink
    }
    
    @objc func anyMethodNameDidReceiveRemoteNotification(_ notif : Notification){
        let dict = notif.userInfo
        //let notifData = dict![kSMNotification_Data_RemoteNotification];
    }
    
    @objc func anyMethodNameDidReceiveDeviceId(_ notif : Notification){
        let dict = notif.userInfo
        let deviceId = dict![SMConstants.kSMNotification_Data_DeviceId];
    }
    
    @objc func anyMethodNameWillDisplayNotification(_ notif : Notification){
    }
    
    @objc func anyMethodNameWillDismissNotification(_ notif : Notification){
    }

    @objc func customAction(_ notif : Notification){
        print("customAction")
    }
}

