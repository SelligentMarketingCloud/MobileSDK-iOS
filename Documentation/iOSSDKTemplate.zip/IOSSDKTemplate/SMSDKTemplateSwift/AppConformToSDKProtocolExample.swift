//
//  File.swift
//  SMSDKTemplateSwift
//
//  Created by Selligent Marketing Cloud on 05/5/2021.
//  Copyright © 2021 Selligent Marketing Cloud. All rights reserved.
//

import Foundation
import SelligentMobileSDK
import WebKit

class AppConformToSDKProtocolExample: NSObject, WKNavigationDelegate, SMManagerInAppMessageDelegate, SMManagerUniversalLinksDelegate {
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == .linkActivated  {
            if let url = navigationAction.request.url,
                let host = url.host, !host.hasPrefix("www.google.com"),
                UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                print(url)
                print("Redirected to browser. No need to open it locally")
                SMManager.shared.removeViewController()
                decisionHandler(.cancel)
            } else {
                print("Open it locally")
                decisionHandler(.allow)
            }
        } else {
            print("not a user click")
            decisionHandler(.allow)
        }
    }
    
    func display(_ inAppMessage: SMInAppMessage) {
        print(inAppMessage.title)
        print(inAppMessage.body)
        print(inAppMessage.arrayIAMLinks)

    }
    
    // The below functions are necessary to keep the SDK webview's navigation arrows working
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        SMManager.shared.webView(webView, didFail: navigation, withError: error)
    }
 
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SMManager.shared.webView(webView, didFinish: navigation)
    }
        
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        SMManager.shared.webView(webView, didCommit: navigation)
    }
    
    // Universal link catching
    func executeLinkAction(_ url: URL) {
        print("Executing custom universal link action")
    }
}
