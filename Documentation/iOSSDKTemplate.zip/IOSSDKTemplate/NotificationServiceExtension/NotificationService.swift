//
//  NotificationService.swift
//  NotificationServiceExtension
//
//  Created by Selligent Marketing Cloud on 27/07/2018.
//  Copyright © 2018 Selligent Marketing Cloud. All rights reserved.
//

import SelligentMobileExtensionsSDK

class NotificationService: SMNotificationService {
    override init() {
        super.init()

        let url = "YourProvidedURL"
        let clientId = "YourClientId"
        let privateKey = "YourPrivateKey"

        self.settings = try? SMManagerSetting(url: url, clientId: clientId, privateKey: privateKey)
        self.settings?.appGroupId = "group.yourGroupName"
        // Whether encryption is enabled or not (needs to be aligned with the Selligent backend configuration), default false
        // self.encryptionEnabled = true
    }
}
