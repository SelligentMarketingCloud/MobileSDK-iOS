//
//  NotificationViewController.swift
//  NotificationContentExtension
//
//  Created by Selligent Marketing Cloud on 17/05/2018.
//  Copyright © 2018 Selligent Marketing Cloud. All rights reserved.
//

import UIKit
import UserNotifications
import UserNotificationsUI
import SelligentMobileExtensionsSDK

class NotificationViewController: UIViewController, UNNotificationContentExtension {

    @IBOutlet weak var displayimageHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet var label: UILabel?
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any required interface initialization here.
    }
    
    func didReceive(_ notification: UNNotification) {
        // UI elements from the storyboard
        self.titleLabel?.text = notification.request.content.title
        self.label?.text = notification.request.content.body
    
        // "SELLIGENT_IMAGE" category must be configured
        var heightConstraint: CGFloat = 0
        
        if(notification.request.content.attachments.count > 0) {
            let attachment:UNNotificationAttachment = notification.request.content.attachments[0];
            
            if (attachment.url.startAccessingSecurityScopedResource()) {
                let imageData = NSData(contentsOf: attachment.url)
                var image: UIImage? = nil
                
                if (imageData != nil) {
                    image = UIImage(data: imageData! as Data)
                    
                    if (image != nil) {
                        let height = self.imageView.frame.size.width / (image!.size.width) * (image!.size.height)
                        let maxHeight = UIScreen.main.bounds.height / 2.5
                        
                        self.imageView.image = image
                        heightConstraint = height > maxHeight ? maxHeight : height
                    }
                }
  
                attachment.url.stopAccessingSecurityScopedResource()
            }
        }
        
        self.displayimageHeightConstraint.constant = heightConstraint

        // Init and start the SDK
        let url = "YourProvidedURL"
        let clientID = "YourClientID"
        let privateKey = "YourPrivateKey"

        // Create the SMManagerSetting instance
        let settings: SMManagerSetting = try! SMManagerSetting(url: url, clientId: clientID, privateKey: privateKey)

        // Provide the App Group Id to the SDK
        settings.appGroupId = "group.selligent.push"

        // Start the SDK
        SMManager.shared.startExtension(with: settings)
        
        // SDK API to add Push Notification buttons
        // "SELLIGENT_BUTTON" category must be configured
        SMManager.shared.didReceive(notification, context: self.extensionContext)
    }

    @available(macCatalystApplicationExtension 14.0, *)
    func didReceive(_ response: UNNotificationResponse, completionHandler completion: @escaping (UNNotificationContentExtensionResponseOption) -> Void) {
        SMManager.shared.didReceive(response, completionHandler: completion)
    }
}
