//
//  NotificationViewController.swift
//  NotificationContentExtension
//
//  Created by Selligent Marketing Cloud on 17/05/2018.
//  Copyright © 2018 Selligent Marketing Cloud. All rights reserved.
//

import SelligentMobileExtensionsSDK

class NotificationViewController: SMNotificationContentViewController {
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        let url = "YourProvidedURL"
        let clientId = "YourClientId"
        let privateKey = "YourPrivateKey"

        self.settings = try? SMManagerSetting(url: url, clientId: clientId, privateKey: privateKey)
        self.settings?.appGroupId = "group.yourGroupName"

        // Whether clicking in a notification button should (always) open the App first, default true.
        // If set to false, actions that do not need the app to be opened to be executed, won't open it (i.e Open Url, Deeplink, Mail, SMS...)
        // self.notificationButtonClicksShouldOpenTheApp = false
    }
}
