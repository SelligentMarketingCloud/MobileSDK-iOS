//
//  ViewController.swift
//  SMSDKTemplateSwift
//
//  Created by Samy Ziat on 21/10/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setIACContainer()
        
        //Send an event
        let eventCustom = SMEvent.init(dictionary: ["key": "value"]);
        SMManager.sharedInstance().send(eventCustom);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @objc func setIACContainer()
    {
        //initialize with your styling options
        let options:SMInAppContentStyleOptions = self.getIACStyleOptions()
        //get the sdk SMInAppContentHTMLViewController
        let htmlVC : SMInAppContentHTMLViewController = SMInAppContentHTMLViewController(forCategory:"anyCategory", inNumberOfBoxes:3, andOptions:options)
        //Check if IAC are available for this type and category
        if(!htmlVC.isEmpty)
        {
            //display SMInAppContentHTMLViewController in your containerView
            SMManager.sharedInstance().showSMController(htmlVC, inContainerView:self.containerView, ofParentViewController:self)
        }
    }
    
    @objc func getIACStyleOptions()-> SMInAppContentStyleOptions
    {
        let greenColor: UIColor                        = UIColor(red:58/255.0, green:190/255.0, blue:190/255.0, alpha:1)
        let backgroundColor: UIColor                   = UIColor(red:0.980, green:0.980, blue:0.980, alpha:0.5)
    
        //call to SMInAppContentStyleOptions constructor
        let smOptions: SMInAppContentStyleOptions       = SMInAppContentStyleOptions.defaultStyling()
    
        //set the properties you need to customise visual aspect of html boxes
        smOptions.marginBetweenFirstBoxAndTopOfView = 0
        smOptions.titleTop                          = 10;
        smOptions.titleTextColor                    = greenColor
        smOptions.showTitleBorderBottom             = true
        smOptions.titleBorderBottomColor            = UIColor(red:0.80, green:0.80, blue:0.80, alpha:0.8)
        smOptions.titleBackgroundColor              = backgroundColor
        smOptions.linkBackgroundColor               = greenColor
        smOptions.linkTextColor                     = UIColor.white
        smOptions.linksAlignment                    = .alignRight
        smOptions.linksMargin                       = 20
        smOptions.linkContentEdgeInsets             = UIEdgeInsetsMake(6.0, 6.0, 6.0, 6.0)
        smOptions.boxBackgroundColor                = backgroundColor
        smOptions.boxBorderWidth                    = 0.0
        smOptions.mainViewBackgroundColor           = UIColor.white
        smOptions.textViewBackgroundColor           = backgroundColor
    
        return smOptions;
    }


}

