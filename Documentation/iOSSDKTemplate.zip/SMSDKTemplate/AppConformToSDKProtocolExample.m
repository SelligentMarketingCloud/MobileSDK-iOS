//
//  AppConformToSDKProtocolExample.m
//  SMSDKTemplate
//
//  Created by Gilbert Schakal on 12/5/2021.
//  Copyright © 2021 Samy Ziat. All rights reserved.
//

#import "AppConformToSDKProtocolExample.h"

#import "SMHelper.h"

@implementation AppConformToSDKProtocolExample
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(nonnull WKNavigationAction *)navigationAction decisionHandler:(nonnull void (^)(WKNavigationActionPolicy))decisionHandler
{
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated) {
        if (navigationAction.request.URL) {
            NSLog(@"%@", navigationAction.request.URL.host);
            if (![navigationAction.request.URL.resourceSpecifier containsString:@"ex path"]) {
                if ([[UIApplication sharedApplication] canOpenURL:navigationAction.request.URL]) {
                    [[UIApplication sharedApplication] openURL:navigationAction.request.URL options:@{} completionHandler:nil];
                    [[SMManager sharedInstance] removeViewController];
                    decisionHandler(WKNavigationActionPolicyCancel);
                }
            } else {
                decisionHandler(WKNavigationActionPolicyAllow);
            }
        }
    } else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

-(void)displayInAppMessage:(SMInAppMessage *)inAppMessage
{
    NSLog(@"title : %@", inAppMessage.title);
    NSLog(@"content : %@", inAppMessage.body);
    NSLog(@"links : %@", inAppMessage.arrayIAMLinks);
}
@end
