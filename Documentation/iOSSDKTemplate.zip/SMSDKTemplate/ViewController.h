//
//  ViewController.h
//  SMSDKTemplate
//
//  Created by Samy Ziat on 16/10/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

