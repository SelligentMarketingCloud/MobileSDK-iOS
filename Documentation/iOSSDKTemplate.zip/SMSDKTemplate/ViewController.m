//
//  ViewController.m
//  SMSDKTemplate
//
//  Created by Samy Ziat on 16/10/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

#import "ViewController.h"

#import "SMHelper.h"

@interface ViewController()

@property (weak, nonatomic) IBOutlet UIView *containerView;

@end




@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //use sdk to display all html in app content for a category in containerView
    [self setIACContainer];

}



- (IBAction)buttonSendEventPressed:(id)sender {
    //  We create a custom-event
    //  Some basic events are already created for you. Please check SMHelper.h
    SMEvent *eventCustom = [SMEvent eventWithDictionary:@{@"key": @"value"}];
    [[SMManager sharedInstance] sendSMEvent:eventCustom];
}


-(void) setIACContainer{
    //initialize with your styling options
    SMInAppContentStyleOptions* options = [self  getIACStyleOptions];
    //get the sdk SMInAppContentHTMLViewController
    SMInAppContentHTMLViewController * htmlVC =[SMInAppContentHTMLViewController viewControllerForCategory:@"anyCategory" InNumberOfBoxes:3 AndOptions:options];
    //Check if IAC are available for this type and category
    if(!htmlVC.isEmpty)
    {
        //display SMInAppContentHTMLViewController in your containerView
        [[SMManager sharedInstance] showSMController:htmlVC InContainerView:_containerView OfParentViewController:self];
    }
}

-(SMInAppContentStyleOptions*) getIACStyleOptions
{
    UIColor *greenColor                         = [UIColor colorWithRed:58/255.0 green:190/255.0 blue:190/255.0 alpha:1];
    UIColor *backgroundColor                    = [UIColor colorWithRed:0.980 green:0.980 blue:0.980 alpha:0.5];

    //call to SMInAppContentStyleOptions constructor
    SMInAppContentStyleOptions *smOptions       = [SMInAppContentStyleOptions defaultStylingOptions];
    
    //set the properties you need to customise visual aspect of html boxes
    smOptions.marginBetweenFirstBoxAndTopOfView = 0;
    smOptions.titleTop                          = 10;
    smOptions.titleTextColor                    = greenColor;
    smOptions.showTitleBorderBottom             = YES;
    smOptions.titleBorderBottomColor            = [UIColor colorWithRed:0.80 green:0.80 blue:0.80 alpha:0.8];
    smOptions.titleBackgroundColor              = backgroundColor;
    smOptions.linkBackgroundColor               = greenColor;
    smOptions.linkTextColor                     = [UIColor whiteColor];
    smOptions.linksAlignment                    = kSMAlignRight;
    smOptions.linksMargin                       = 20;
    smOptions.linkContentEdgeInsets             = UIEdgeInsetsMake(6.0, 6.0, 6.0, 6.0);
    smOptions.boxBackgroundColor                = backgroundColor;
    smOptions.boxBorderWidth                    = 0.0;
    smOptions.mainViewBackgroundColor           = [UIColor whiteColor];
    smOptions.textViewBackgroundColor           = backgroundColor;

    return smOptions;
    
}



@end
