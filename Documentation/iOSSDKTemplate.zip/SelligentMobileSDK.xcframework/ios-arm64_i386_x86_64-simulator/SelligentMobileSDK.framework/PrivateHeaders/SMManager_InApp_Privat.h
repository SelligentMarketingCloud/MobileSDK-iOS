//
//  SMManager_InApp_Privat.h
//  MobileSDK
//
//  Created by Gilbert Schakal on 30/08/16.
//  Copyright © 2016 Selligent. All rights reserved.
//


#import "SMManager+InApp.h"


@interface SMManager (InApp_Privat)


- (void)fetchInApp;


@end

