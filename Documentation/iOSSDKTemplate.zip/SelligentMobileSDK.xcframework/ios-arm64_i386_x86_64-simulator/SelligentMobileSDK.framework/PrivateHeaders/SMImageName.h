//
//  SMImageName.h
//  TestConstraints
//
//  Created by Samy Ziat on 12/08/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

static NSString* kSMImageName_Button_Close        = @"close";
static NSString* kSMImageName_Button_Hamburger    = @"menu";
static NSString* kSMImageName_Button_Validate     = @"validate";
static NSString* kSMImageName_Button_Camera       = @"camera";
static NSString* kSMImageName_Button_PhotoLibrary = @"PhotoLib";
static NSString* kSMImageName_Button_KeyboardHide = @"keyboardHide";
static NSString* kSMImageName_Button_Forward      = @"Forward";
static NSString* kSMImageName_Button_Back         = @"Back";
static NSString* kSMImageName_Button_CloseRed     = @"CloseRed";
