//
//  SMViewControllerStandardAlert.h
//  MobileSDK
//
//  Created by Gauthier Dumont on 10/07/15.
//  Copyright (c) 2015 Selligent. All rights reserved.
//

#import "SMNotifMessageViewController.h"

@interface SMNotifAlertStandardViewController : SMNotifMessageViewController <UIActionSheetDelegate>


@end
