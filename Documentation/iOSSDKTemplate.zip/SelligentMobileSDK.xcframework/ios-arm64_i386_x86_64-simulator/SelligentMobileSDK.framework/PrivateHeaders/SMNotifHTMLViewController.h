//
//  SMNotifHTMLViewController.h
//  MobileSDK
//
//  Created by Samy Ziat on 13/10/15.
//  Copyright (c) 2015 Selligent. All rights reserved.
//

#import "SMNotifMessageViewController.h"

@interface SMNotifHTMLViewController : SMNotifMessageViewController

@end
