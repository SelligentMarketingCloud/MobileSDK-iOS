//
//  SMEventRegister.h
//  MobileSDK
//
//  Created by Gilbert Schakal on 07/10/16.
//  Copyright © 2016 Selligent. All rights reserved.
//

#import "SMEventSetInfo.h"

@interface SMEventRegister : SMEventSetInfo

@end
