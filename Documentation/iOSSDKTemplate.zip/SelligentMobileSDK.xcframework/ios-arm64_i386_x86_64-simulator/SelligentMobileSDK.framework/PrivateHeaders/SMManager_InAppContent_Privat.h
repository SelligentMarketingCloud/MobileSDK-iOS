//
//  SMManager_InAppContent_Privat.h
//  MobileSDK
//
//  Created by Gilbert Schakal on 11/03/16.
//  Copyright © 2016 Selligent. All rights reserved.
//

#import "SMManager+InAppContent.h"


@interface SMManager (InAppContent_Privat)


- (void)fetchInAppContent;


@end
