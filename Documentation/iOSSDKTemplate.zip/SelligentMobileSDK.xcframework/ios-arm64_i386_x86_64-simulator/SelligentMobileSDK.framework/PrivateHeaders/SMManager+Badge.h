//
//  SMManager+Badge.h
//  MobileSDK
//
//  Created by Samy Ziat on 07/08/15.
//  Copyright (c) 2015 Selligent. All rights reserved.
//

#import "SMManager_Private.h"

@interface SMManager (Badge)

- (void)clearBadge;

@end
