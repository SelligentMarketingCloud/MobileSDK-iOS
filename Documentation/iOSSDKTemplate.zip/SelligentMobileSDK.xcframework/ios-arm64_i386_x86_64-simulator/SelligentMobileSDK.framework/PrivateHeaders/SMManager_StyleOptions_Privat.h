//
//  SMManager_StyleOptions_Privat.h
//  MobileSDK
//
//  Created by Gilbert Schakal on 30/04/16.
//  Copyright © 2016 Selligent. All rights reserved.
//

#import "SMManager+StyleOptions.h"


@interface SMManager (StyleOptions_privat)

- (SMInAppContentStyleOptions*)fetchStyleOptions;
@end
