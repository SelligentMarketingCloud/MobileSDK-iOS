//
//  SMImage_DataRepresentation.h
//  TestConstraints
//
//  Created by Samy Ziat on 12/08/15.
//  Copyright (c) 2015 Samy Ziat. All rights reserved.
//

#import <UIKit/UIKit.h>



NSString* dataRepresentation_ButtonClose(void);

NSString* dataRepresentation_ButtonHamburger(void);

NSString* dataRepresentation_ButtonValidate(void);

NSString* dataRepresentation_ButtonCamera(void);

NSString* dataRepresentation_PhotoLibrary(void);

NSString* dataRepresentation_KeyboardHide(void);

NSString* dataRepresentation_Back(void);

NSString* dataRepresentation_Forward(void);

NSString* dataRepresentation_CloseRed(void);




