//
//  SMMessageNature.h
//  MobileSDK
//
//  Created by Gilbert Schakal on 16/03/16.
//  Copyright © 2016 Selligent. All rights reserved.
//


typedef NS_ENUM(NSInteger, SMMessageNature) {
    kSMMN_Push,
    kSMMN_IAContent,
    kSMMN_IAMessage
};

