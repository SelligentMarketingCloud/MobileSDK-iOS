//
//  SMNotifPhotoViewController.h
//  MobileSDK
//
//  Created by Samy Ziat on 08/09/15.
//  Copyright (c) 2015 Selligent. All rights reserved.
//

#import "SMBTNReturnMediaViewController.h"


@interface SMBTNPhotoViewController : SMBTNReturnMediaViewController

@end
