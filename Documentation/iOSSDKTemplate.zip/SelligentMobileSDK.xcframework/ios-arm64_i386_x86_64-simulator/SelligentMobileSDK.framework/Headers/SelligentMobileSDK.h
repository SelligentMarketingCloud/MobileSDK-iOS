//
//  SelligentMobileSDK.h
//  SelligentMobileSDK
//
//  Created by Thibaut Colin on 07/04/2021.
//  Copyright © 2021 Selligent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SMHelper.h"

//! Project version number for SelligentMobileSDK.
FOUNDATION_EXPORT double SelligentMobileSDKVersionNumber;

//! Project version string for SelligentMobileSDK.
FOUNDATION_EXPORT const unsigned char SelligentMobileSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SelligentMobileSDK/PublicHeader.h>


